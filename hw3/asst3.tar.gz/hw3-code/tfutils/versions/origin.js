{
    "user": "jeremydhoon",
    "repo": "tfutils",
    "branches": {
        "release": "release",
        "master": "master"
    }
}