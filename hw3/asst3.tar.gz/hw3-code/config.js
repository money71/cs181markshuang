{
    "title": "CS181 Homework 3",
    "subtitle": "Clustering",
    "workmodule": "clust.py",
    "testmodule": "testclust.py",
    "taskmodule": "taskclust.py",
    "usertestdir": "usertests",
    "build_call_graph": false,
    "indent": 4,
    "static": ["hw3", "hw3.bat", "Makefile", "submit.sh",
               "adults.txt", "adults-small.txt",
               "3d-scatter.p", "clust1.dat", "clust2.dat", "181adult.names" ]
}
